﻿import 'package:supabase_flutter/supabase_flutter.dart';

Future<void> diagnoseSupabaseStorage() async {
  final supabase = Supabase.instance.client;

  print('');
  print('===== SUPABASE STORAGE DIAGNOSTIC =====');

  final user = supabase.auth.currentUser;

  print('[AUTH] User exists: ${user != null}');

  if (user != null) {
    print('[AUTH] User id: ${user.id}');
    print('[AUTH] Email: ${user.email}');
  }

  try {
    final buckets = await supabase.storage.listBuckets();

    print('[STORAGE] Bucket count: ${buckets.length}');

    for (final bucket in buckets) {
      print(
        '[STORAGE] Bucket: '
        '${bucket.id} | '
        'public: ${bucket.public}',
      );
    }

    print('===== SUPABASE STORAGE DIAGNOSTIC END =====');
    print('');
  } catch (error, stackTrace) {
    print('');
    print('===== SUPABASE STORAGE DIAGNOSTIC ERROR =====');
    print('[STORAGE] Error: $error');
    print('[STORAGE] Stack: $stackTrace');
    print('============================================');
    print('');
  }
}
