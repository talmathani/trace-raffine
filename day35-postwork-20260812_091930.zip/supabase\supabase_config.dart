﻿import 'package:supabase_flutter/supabase_flutter.dart';

abstract final class SupabaseConfig {
  static const String projectUrl = 'https://cncjkeeucwxiazfgdbiv.supabase.co';
  static const String publishableKey =
      String.fromEnvironment('SUPABASE_PUBLISHABLE_KEY');

  static Future<void> initialize() async {
    final key = publishableKey.trim();

    if (key.isEmpty) {
      throw StateError(
        'SUPABASE_PUBLISHABLE_KEY is missing.',
      );
    }

    await Supabase.initialize(
      url: projectUrl,
      publishableKey: key,
    );
  }

  static SupabaseClient get client =>
      Supabase.instance.client;
}
