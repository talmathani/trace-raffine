﻿import 'package:supabase_flutter/supabase_flutter.dart';

Future<void> main() async {
  const supabaseUrl = 'https://cncjkeeucwxiazfgdbiv.supabase.co';

  const publishableKey = 'REPLACE_WITH_PROJECT_PUBLISHABLE_KEY';

  await Supabase.initialize(
    url: supabaseUrl,
    publishableKey: publishableKey,
  );

  final supabase = Supabase.instance.client;

  const bucket = 'designer_designs';

  const path =
      '52550929-6d5f-43ce-947b-682116ca58c5/8CnqlXNpnzcWyJgwGQ3D/design.jpg';

  print('');
  print('===== DIRECT STORAGE API TEST =====');
  print('[1] URL: $supabaseUrl');
  print('[2] Bucket: $bucket');
  print('[3] Path: $path');

  final user = supabase.auth.currentUser;

  print('[4] Current user exists: ${user != null}');

  if (user != null) {
    print('[4] UID: ${user.id}');
    print('[4] Email: ${user.email}');
  }

  print('');
  print('[5] TEST LIST');

  try {
    final files = await supabase.storage
        .from(bucket)
        .list(
          path: '52550929-6d5f-43ce-947b-682116ca58c5/8CnqlXNpnzcWyJgwGQ3D',
        );

    print('[LIST] SUCCESS');
    print('[LIST] Count: ${files.length}');

    for (final file in files) {
      print('[LIST] name=${file.name}');
      print('[LIST] id=${file.id}');
      print('[LIST] metadata=${file.metadata}');
    }
  } catch (e, st) {
    print('[LIST] FAILED');
    print('[LIST] ERROR: $e');
    print('[LIST] STACK: $st');
  }

  print('');
  print('[6] TEST SIGNED URL');

  try {
    final signedUrl = await supabase.storage
        .from(bucket)
        .createSignedUrl(
          path,
          3600,
        );

    print('[SIGNED URL] SUCCESS');
    print('[SIGNED URL]');
    print(signedUrl);
  } on StorageException catch (e, st) {
    print('[SIGNED URL] STORAGE ERROR');
    print('[SIGNED URL] statusCode: ${e.statusCode}');
    print('[SIGNED URL] message: ${e.message}');
    print('[SIGNED URL] error: $e');
    print('[SIGNED URL] stack: $st');
  } catch (e, st) {
    print('[SIGNED URL] UNKNOWN ERROR');
    print('[SIGNED URL] error: $e');
    print('[SIGNED URL] stack: $st');
  }

  print('');
  print('===== DIRECT STORAGE API TEST END =====');
}
