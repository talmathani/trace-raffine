﻿import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class SupabaseAuthDataSource {
  SupabaseAuthDataSource({
    SupabaseClient? supabaseClient,
  }) : _supabase = supabaseClient ?? Supabase.instance.client;

  final SupabaseClient _supabase;

  Stream<AuthState> get authStateChanges {
    return _supabase.auth.onAuthStateChange;
  }

  User? get currentUser => _supabase.auth.currentUser;

  String _normalizeEmail(String email) {
    final normalized = email
        .trim()
        .replaceAll(RegExp(r'\s+'), '')
        .toLowerCase();

    final emailRegex = RegExp(
      r'^[A-Za-z0-9.!#$%&*+/=?^_`{|}~-]+@'
      r'[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?'
      r'(?:\.[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?)+$',
    );

    if (!emailRegex.hasMatch(normalized)) {
      throw const AuthException(
        'صيغة البريد الإلكتروني غير صحيحة.',
      );
    }

    return normalized;
  }

  Future<void> _diagnoseStorageAfterLogin() async {
    debugPrint('');
    debugPrint('===== SUPABASE STORAGE LOGIN DIAGNOSTIC =====');

    final user = _supabase.auth.currentUser;

    debugPrint(
      '[AUTH] User exists: ${user != null}',
    );

    if (user != null) {
      debugPrint(
        '[AUTH] User ID: ${user.id}',
      );
      debugPrint(
        '[AUTH] Email: ${user.email}',
      );
    }

    try {
      final buckets = await _supabase.storage.listBuckets();

      debugPrint(
        '[STORAGE] Bucket count: ${buckets.length}',
      );

      if (buckets.isEmpty) {
        debugPrint(
          '[STORAGE] NO BUCKETS FOUND',
        );
      }

      for (final bucket in buckets) {
        debugPrint(
          '[STORAGE] Bucket ID: ${bucket.id}',
        );
        debugPrint(
          '[STORAGE] Bucket name: ${bucket.name}',
        );
        debugPrint(
          '[STORAGE] Public: ${bucket.public}',
        );
        debugPrint(
          '[STORAGE] File size limit: ${bucket.fileSizeLimit}',
        );
        debugPrint('');
      }

      debugPrint(
        '===== SUPABASE STORAGE DIAGNOSTIC SUCCESS =====',
      );
      debugPrint('');
    } catch (error, stackTrace) {
      debugPrint('');
      debugPrint(
        '===== SUPABASE STORAGE DIAGNOSTIC ERROR =====',
      );
      debugPrint(
        '[STORAGE] Error: $error',
      );
      debugPrint(
        '[STORAGE] Stack: $stackTrace',
      );
      debugPrint(
        '================================================',
      );
      debugPrint('');
    }
  }

  Future<AuthResponse> signInWithEmailAndPassword({
    required String email,
    required String password,
  }) async {
    final normalizedEmail = _normalizeEmail(email);

    debugPrint(
      'Supabase login start: $normalizedEmail',
    );

    try {
      final result = await _supabase.auth
          .signInWithPassword(
            email: normalizedEmail,
            password: password,
          )
          .timeout(
            const Duration(seconds: 15),
          );

      debugPrint(
        'Supabase login success: ${result.user?.email}',
      );

      await _diagnoseStorageAfterLogin();

      return result;
    } on AuthException catch (error) {
      debugPrint(
        'Supabase login error: ${error.message}',
      );
      rethrow;
    }
  }

  Future<AuthResponse> createUserWithEmailAndPassword({
    required String email,
    required String password,
  }) async {
    final normalizedEmail = _normalizeEmail(email);

    debugPrint(
      'Supabase registration start: $normalizedEmail',
    );

    try {
      final result = await _supabase.auth.signUp(
        email: normalizedEmail,
        password: password,
      );

      debugPrint(
        'Supabase registration result: '
        'user=${result.user?.email}, '
        'session=${result.session != null}',
      );

      return result;
    } on AuthException catch (error) {
      debugPrint(
        'Supabase registration error: ${error.message}',
      );
      rethrow;
    }
  }

  Future<void> resendEmailVerification() async {
    final user = _supabase.auth.currentUser;

    if (user == null || user.email == null) {
      throw const AuthException(
        'لا يوجد مستخدم مسجل حاليًا.',
      );
    }

    if (user.emailConfirmedAt != null) {
      return;
    }

    await _supabase.auth.resend(
      type: OtpType.signup,
      email: user.email!,
    );
  }

  Future<bool> reloadAndCheckEmailVerification() async {
    await _supabase.auth.refreshSession();

    final user = _supabase.auth.currentUser;

    if (user == null) {
      return false;
    }

    return user.emailConfirmedAt != null;
  }

  Future<void> sendPasswordResetEmail({
    required String email,
  }) async {
    final normalizedEmail = _normalizeEmail(email);

    await _supabase.auth.resetPasswordForEmail(
      normalizedEmail,
    );
  }

  Future<void> signOut() {
    return _supabase.auth.signOut();
  }
}
